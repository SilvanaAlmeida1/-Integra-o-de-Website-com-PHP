#Programação De Sistemas Para Web I
Integração de Website com PHP
Return to: Semana 5 - 19/0...
Utilize um Website qualquer (pode ser um desenvolvido na disciplina de WebDesign) ou faça um novo.

Utilize no mínimo dois input  de qualquer tipo e um botão enviar em uma determina página do Website. Quando o usuário clicar no botão, serão enviadas informações, através de POST, para um arquivo php (back) que deve imprimi-los na tela, similar ao exemplo visto em aula. 

Nesta atividade, envie os arquivos .html e .php com a implementação. Se preferir, pode compactar os arquivos. Se o seu arquivo compactado ultrapassar o limite do Moodle (8Mb), suba o código para o Drive ou git e envie o link em um arquivo texto qualquer.

A estética do front não será avaliada, e sim a integração do Website com o back (php). 

obs1: Se você estiver utilizando um Website feito em Webdesign, talvez seja necessário fazer algumas adaptações / criações, sobretudo no form e seus inputs.

obs2: Se tiver dificuldade, use como referência o exemplo visto em aula. 
